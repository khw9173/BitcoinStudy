<TS language="ar" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>انقر بالزر الايمن لتعديل العنوان</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>انشأ عنوان جديد</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;جديد</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>قم بنسخ القوانين المختارة لحافظة النظام</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;نسخ</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>ا&amp;غلاق</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>حذف العنوان المحدد من القائمة</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>تحميل البيانات في علامة التبويب الحالية إلى ملف.</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;تصدير</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;أمسح</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>اختر العنوان الذي سترسل له العملات</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>اختر العنوان الذي تستقبل عليه العملات</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;اختر</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>ارسال العناوين</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>استقبال العناوين</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>هذه هي عناوين Bitcion التابعة لك من أجل إرسال الدفعات. تحقق دائما من المبلغ و عنوان المرسل المستقبل قبل إرسال العملات</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>هذه هي عناوين Bitcion التابعة لك من أجل إستقبال الدفعات. ينصح استخدام عنوان جديد من أجل كل صفقة</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>انسخ العنوان</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>نسخ &amp;الوصف</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>تعديل</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>تصدير قائمة العناوين</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>ملف مفصول بفواصل (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>فشل التصدير</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>لقد حدث خطأ أثناء  حفظ قائمة العناوين إلى %1. يرجى المحاولة مرة أخرى.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>وصف</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>عنوان</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(لا وصف)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>حوار جملة السر</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>ادخل كلمة المرور</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>كلمة مرور جديدة</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>ادخل كلمة المرور الجديدة مرة أخرى</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>أدخل عبارة مرور جديدة إلى المحفظة. الرجاء استخدام عبارة مرور تتكون من10 حروف عشوائية على الاقل, أو أكثر من 7 كلمات</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>تشفير المحفظة</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>هذه العملية تحتاج كلمة مرور محفظتك لفتحها</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>إفتح المحفظة</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>هذه العملية تحتاج كلمة مرور محفظتك لفك تشفيرها </translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>فك تشفير المحفظة</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>تغيير كلمة المرور</translation>
    </message>
    <message>
        <source>Enter the old passphrase and new passphrase to the wallet.</source>
        <translation>أدخل كلمة المرور القديمة والجديدة للمحفظة.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>تأكيد تشفير المحفظة</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>تحذير: إذا قمت بتشفير محفظتك وفقدت كلمة المرور الخاص بك, ستفقد كل عملات BITCOINS الخاصة بك.</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>هل أنت متأكد من رغبتك في تشفير محفظتك ؟</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>محفظة مشفرة</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>هام: أي نسخة إحتياطية سابقة  قمت بها لمحفظتك يجب استبدالها  بأخرى حديثة، مشفرة. لأسباب أمنية، النسخ الاحتياطية السابقة لملفات المحفظة الغير مشفرة تصبح عديمة الفائدة مع بداية استخدام المحفظة المشفرة الجديدة.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>فشل تشفير المحفظة</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>فشل تشفير المحفظة بسبب خطأ داخلي. لم يتم تشفير محفظتك.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>كلمتي المرور ليستا متطابقتان</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>فشل فتح المحفظة</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>كلمة المرور التي تم إدخالها لفك تشفير المحفظة غير صحيحة.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>فشل   فك التشفير المحفظة</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>لقد تم تغير عبارة مرور المحفظة بنجاح</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>تحذير: مفتاح الحروف الكبيرة مفعل</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    <message>
        <source>IP/Netmask</source>
        <translation>عنوان البروتوكول/قناع</translation>
    </message>
    <message>
        <source>Banned Until</source>
        <translation>محظور حتى</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>التوقيع و الرسائل</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>مزامنة مع الشبكة ...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;نظرة عامة</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>جهاز</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>إظهار نظرة عامة على المحفظة</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;المعاملات</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>تصفح سجل المعاملات</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>خروج</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>الخروج من التطبيق</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>حوالي %1</translation>
    </message>
    <message>
        <source>Show information about %1</source>
        <translation>أظهر المعلومات حولة %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>عن &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>اظهر المعلومات</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;خيارات ...</translation>
    </message>
    <message>
        <source>Modify configuration options for %1</source>
        <translation>تغيير خيارات الإعداد لأساس ل%1</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;تشفير المحفظة</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;نسخ احتياط للمحفظة</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;تغيير كلمة المرور</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>ارسال العناوين.</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>استقبال العناوين</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>افتح &amp;URI...</translation>
    </message>
    <message>
        <source>Click to disable network activity.</source>
        <translation>اضغط لإلغاء تفعيل الشبكه</translation>
    </message>
    <message>
        <source>Network activity disabled.</source>
        <translation>تم إلغاء تفعيل الشبكه</translation>
    </message>
    <message>
        <source>Click to enable network activity again.</source>
        <translation>اضغط لتفعيل الشبكه مره أخرى</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>إعادة الفهرسة الكتل على القرص ...</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>ارسل عملات الى عنوان بيتكوين</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>احفظ نسخة احتياطية للمحفظة في مكان آخر</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>تغيير كلمة المرور المستخدمة لتشفير المحفظة</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;نافذة المعالجة</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>إفتح وحدة التصحيح و التشخيص</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;التحقق من الرسالة...</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>بت كوين</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>محفظة</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;ارسل</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;استقبل</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;عرض / اخفاء</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>عرض او اخفاء النافذة الرئيسية</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>تشفير المفتاح الخاص بمحفظتك</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>وقَع الرسائل بواسطة ال: Bitcoin الخاص بك لإثبات امتلاكك لهم</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>تحقق من الرسائل للتأكد من أنَها وُقعت برسائل Bitcoin محدَدة</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ملف</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;الاعدادات</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;مساعدة</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>شريط أدوات علامات التبويب</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation>أطلب دفعات (يولد كودات الرمز المربع وبيت كوين: العناوين المعطاة)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>عرض قائمة عناوين الإرسال المستخدمة والملصقات</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>عرض قائمة عناوين الإستقبال المستخدمة والملصقات</translation>
    </message>
    <message>
        <source>Open a bitcoin: URI or payment request</source>
        <translation>فتح URI : Bitcoin أو طلب دفع</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;خيارات سطر الأوامر</translation>
    </message>
    <message>
        <source>Indexing blocks on disk...</source>
        <translation>ترتيب الفهرسة الكتل على القرص...</translation>
    </message>
    <message>
        <source>Processing blocks on disk...</source>
        <translation>معالجة الكتل على القرص...</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>خلف %1</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>تم توليد الكتلة المستقبلة الأخيرة منذ %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>المعاملات بعد ذلك لن تكون مريئة بعد.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>خطأ</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>تحذير</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>معلومات</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>محدث</translation>
    </message>
    <message>
        <source>Show the %1 help message to get a list with possible Bitcoin command-line options</source>
        <translation>بين اشارة المساعدة %1 للحصول على قائمة من خيارات اوامر البت كوين المحتملة </translation>
    </message>
    <message>
        <source>%1 client</source>
        <translation>الزبون %1</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>اللحاق بالركب ...</translation>
    </message>
    <message>
        <source>Date: %1
</source>
        <translation>التاريخ %1


</translation>
    </message>
    <message>
        <source>Amount: %1
</source>
        <translation>الكمية %1
</translation>
    </message>
    <message>
        <source>Type: %1
</source>
        <translation>نوع %1
</translation>
    </message>
    <message>
        <source>Label: %1
</source>
        <translation>علامه: %1
</translation>
    </message>
    <message>
        <source>Address: %1
</source>
        <translation>عنوان %1
</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>المعاملات  المرسلة</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>المعاملات الواردة</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>المحفظة &lt;b&gt;مشفرة&lt;/b&gt; و &lt;b&gt;مفتوحة&lt;/b&gt; حاليا</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>المحفظة &lt;b&gt;مشفرة&lt;/b&gt; و &lt;b&gt;مقفلة&lt;/b&gt; حاليا</translation>
    </message>
    <message>
        <source>A fatal error occurred. Bitcoin can no longer continue safely and will quit.</source>
        <translation>خطأ فادح حدث . لا يمكن اتمام بيتكوين بامان سيتم الخروج</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>اختيار العمله</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>الكمية :</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>بايت</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>القيمة :</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>رسوم :</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>غبار:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>بعد الرسوم :</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>تعديل :</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>عدم اختيار الجميع</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>صيغة الشجرة</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>صيغة القائمة</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>مبلغ</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>مستقبل مع ملصق</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>مستقبل مع عنوان</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>تأكيدات</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>تأكيد</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>  انسخ عنوان</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation> انسخ التسمية</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>نسخ الكمية</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>نسخ رقم العملية</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>نسخ الكمية </translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>نسخ الرسوم</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>نسخ بعد الرسوم</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>نسخ البايتات </translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>نسخ التعديل</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>نعم</translation>
    </message>
    <message>
        <source>no</source>
        <translation>لا</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(لا وصف)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(تغير)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>عدل العنوان</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;وصف</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>الملصق المرتبط بقائمة العناوين المدخلة</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>العنوان المرتبط بقائمة العناوين المدخلة. و التي يمكن تعديلها فقط بواسطة ارسال العناوين</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;العنوان</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>عنوان أستلام جديد</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>عنوان إرسال جديد</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>تعديل عنوان الأستلام</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>تعديل عنوان الارسال</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Bitcoin address.</source>
        <translation>العنوان المدخل "%1" ليس عنوان بيت كوين صحيح.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>هدا العنوان "%1" موجود مسبقا في دفتر العناوين</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation> يمكن فتح المحفظة.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>فشل توليد مفتاح جديد.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>سيتم انشاء دليل بيانات جديد</translation>
    </message>
    <message>
        <source>name</source>
        <translation>الاسم</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>الدليل موجوج بالفعل. أضف %1 لو نويت إنشاء دليل جديد هنا.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>المسار موجود بالفعل، وهو ليس دليلاً.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>لا يمكن انشاء دليل بيانات هنا .</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>النسخة</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>حوالي %1</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>خيارات سطر الأوامر</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>المستخدم</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>خيارات سطر الأوامر</translation>
    </message>
    <message>
        <source>UI Options:</source>
        <translation>خيارات واجهة المستخدم</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: %u)</source>
        <translation>اختر دليل البيانات عند بدء التشغير (افتراضي: %u)</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>أضع لغة, على سبيل المثال " de_DE "  (افتراضي:- مكان النظام)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>الدخول مصغر</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>أضع شهادة بروتوكول الشبقة الأمنية لطلب المدفوع (افتراضي: -نظام-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: %u)</source>
        <translation>أظهر شاشة البداية عند بدء التشغيل (افتراضي: %u)</translation>
    </message>
    <message>
        <source>Reset all settings changed in the GUI</source>
        <translation>اعد تعديل جميع النظم المتغيرة في GUI</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>أهلا</translation>
    </message>
    <message>
        <source>Welcome to %1.</source>
        <translation> اهلا بكم في %1</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where %1 will store its data.</source>
        <translation>بما انه هذه اول مرة لانطلاق هذا البرنامج, فيمكنك ان تختار اين سيخزن %1 بياناته</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>استخدام دليل البانات الافتراضي</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>استخدام دليل بيانات مخصص:</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>خطأ: لا يمكن تكوين دليل بيانات مخصص ل %1</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>خطأ</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>نمودج</translation>
    </message>
    <message>
        <source>Unknown...</source>
        <translation>غير معرف</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>إخفاء</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>افتح URL</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>حدد طلب الدفع من ملف او URI</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>حدد ملف طلب الدفع</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>حدد ملف طلب الدفع لفتحه</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>خيارات ...</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;الرئيسي</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>م ب</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>إقبل التواصل من الخارج</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>عنوان النطاق للطرف الثالث</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;استعادة الخيارات</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;الشبكة</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>&amp;محفظة</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>تصدير</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>بروكسي &amp;اي بي:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;المنفذ:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>منفذ البروكسي (مثلا 9050)</translation>
    </message>
    <message>
        <source>Used for reaching peers via:</source>
        <translation>مستخدم للاتصال بالاصدقاء من خلال:</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>نافذه</translation>
    </message>
    <message>
        <source>Hide tray icon</source>
        <translation>اخفاء لوحة الايقون</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;عرض</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>واجهة المستخدم &amp;اللغة:</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>تم</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>الغاء</translation>
    </message>
    <message>
        <source>default</source>
        <translation>الافتراضي</translation>
    </message>
    <message>
        <source>none</source>
        <translation>لا شيء</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>تأكيد استعادة الخيارات</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>عنوان الوكيل توفيره غير صالح.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>نمودج</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>متوفر</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>معلق:</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>غير ناضجة</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>المجموع:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>رصيدك الكلي الحالي</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Bad response from server %1</source>
        <translation>استجابة سيئة من الملقم %1</translation>
    </message>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>مبلغ</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 ساعة</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 دقيقة</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>غير معروف</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 و %2</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;حفظ الصورة</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;نسخ الصورة</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>حفظ رمز الاستجابة السريعة QR</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>صورة PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>غير معروف</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>نسخه العميل</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>المعلومات</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>نافذة المعالجة</translation>
    </message>
    <message>
        <source>General</source>
        <translation>عام</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>وقت البدء</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>الشبكه</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>الاسم</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>عدد الاتصالات</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>إستقبل</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>تم الإرسال</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;اصدقاء</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>جهة</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>خدمات</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>آخر استقبال</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>آخر إرسال</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>الفتح</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;حركة مرور الشبكة</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;مسح</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>المجاميع</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>داخل:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>خارج:</translation>
    </message>
    <message>
        <source>1 &amp;hour</source>
        <translation>1 &amp;ساعة</translation>
    </message>
    <message>
        <source>1 &amp;day</source>
        <translation>1 &amp; يوم</translation>
    </message>
    <message>
        <source>1 &amp;week</source>
        <translation>1 &amp; اسبوع</translation>
    </message>
    <message>
        <source>1 &amp;year</source>
        <translation>1 &amp; سنة</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>استخدم اسهم الاعلى و الاسفل للتنقل بين السجلات و &lt;b&gt;Ctrl-L&lt;/b&gt;  لمسح الشاشة</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 بايت</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 كيلو بايت</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 ميقا بايت</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 قيقا بايت</translation>
    </message>
    <message>
        <source>never</source>
        <translation>ابدا</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>داخل</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>خارجي</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>نعم</translation>
    </message>
    <message>
        <source>No</source>
        <translation>لا</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>غير معرف</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;القيمة</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;وصف :</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;رسالة:</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>مسح كل حقول النموذج المطلوبة</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>مسح</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>سجل طلبات الدفع</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>عرض</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>ازل</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation> انسخ التسمية</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>انسخ الرسالة</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>نسخ الكمية</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>رمز كيو ار</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>نسخ  &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>نسخ &amp;العنوان</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;حفظ الصورة</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>معلومات الدفع</translation>
    </message>
    <message>
        <source>URI</source>
        <translation> URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>عنوان</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>مبلغ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>وصف</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>رسالة </translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>وصف</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>رسالة </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(لا وصف)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>( لا رسائل )</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>إرسال Coins</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>اختيار تلقائيا</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>الرصيد غير كافي!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>الكمية :</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>بايت</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>القيمة :</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>رسوم :</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>بعد الرسوم :</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>تعديل :</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>رسوم المعاملة:</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>إخفاء</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>طبيعي</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>سريع</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>إرسال إلى عدة مستلمين في وقت واحد</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>أضافة &amp;مستلم</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>مسح كل حقول النموذج المطلوبة</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>غبار:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>مسح الكل</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>الرصيد:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>تأكيد الإرسال</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;ارسال</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>نسخ الكمية </translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>نسخ الكمية</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>نسخ الرسوم</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>نسخ بعد الرسوم</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>نسخ البايتات </translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>نسخ التعديل</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 الى %2</translation>
    </message>
    <message>
        <source>or</source>
        <translation>أو</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>تأكيد الإرسال Coins</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>المبلغ المدفوع يجب ان يكون اكبر من 0</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>القيمة تتجاوز رصيدك</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>المجموع يتجاوز رصيدك عندما يتم اضافة %1 رسوم العملية</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(لا وصف)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;القيمة</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>ادفع &amp;الى :</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;وصف :</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>اختر عنوانا مستخدم سابقا</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>هذا دفع اعتيادي</translation>
    </message>
    <message>
        <source>The Bitcoin address to send the payment to</source>
        <translation>عنوان البت كوين المرسل اليه الدفع</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>انسخ العنوان من لوحة المفاتيح</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>ازل هذه المداخله</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>الرسائل</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>ادفع &amp;الى :</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>إدخال تسمية لهذا العنوان لإضافته إلى دفتر العناوين الخاص بك</translation>
    </message>
</context>
<context>
    <name>SendConfirmationDialog</name>
    <message>
        <source>Yes</source>
        <translation>نعم</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>لا توقف عمل الكمبيوتر حتى تختفي هذه النافذة</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;توقيع الرسالة</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>اختر عنوانا مستخدم سابقا</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>انسخ العنوان من لوحة المفاتيح</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>ادخل الرسالة التي تريد توقيعها هنا</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>التوقيع</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>وقع الرسالة لتثبت انك تمتلك عنوان البت كوين هذا</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>توقيع $الرسالة</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>مسح الكل</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;تحقق رسالة</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>تحقق &amp;الرسالة</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>اضغط  "توقيع الرسالة" لتوليد التوقيع</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>العنوان المدخل غير صالح</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>الرجاء التأكد من العنوان والمحاولة مرة اخرى</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>العنوان المدخل لا يشير الى مفتاح</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>تم الغاء عملية فتح المحفظة</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>المفتاح الخاص للعنوان المدخل غير موجود.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>فشل توقيع الرسالة.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>الرسالة موقعة.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>فضلا تاكد من التوقيع وحاول مرة اخرى</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>فشلت عملية التأكد من الرسالة.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>تم تأكيد الرسالة.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>مفتوح حتى %1</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1 غير متواجد</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>غير مؤكدة/%1</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>تأكيد %1</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>الحالة.</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>,  لم يتم حتى الآن البث بنجاح</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>المصدر</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>تم اصداره.</translation>
    </message>
    <message>
        <source>From</source>
        <translation>من</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>غير معروف</translation>
    </message>
    <message>
        <source>To</source>
        <translation>الى</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>عنوانه</translation>
    </message>
    <message>
        <source>label</source>
        <translation>علامة</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>غير مقبولة</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>دين</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>رسوم المعاملة</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>رسالة </translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>تعليق</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>رقم المعاملة</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>تاجر</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>معاملة</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>مبلغ</translation>
    </message>
    <message>
        <source>true</source>
        <translation>صحيح</translation>
    </message>
    <message>
        <source>false</source>
        <translation>خاطئ</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>يبين هذا الجزء وصفا مفصلا لهده المعاملة</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>النوع</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>وصف</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>مفتوح حتى %1</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>غير متصل</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>يتعارض</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>لم يتم تلقى هذه الكتلة (Block) من قبل أي العقد الأخرى وربما لن تكون مقبولة!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>ولدت ولكن لم تقبل</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>استقبل مع</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>استقبل من</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>أرسل إلى</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>دفع لنفسك</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Mined</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>غير متوفر</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(لا وصف)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>حالة المعاملة. تحوم حول هذا الحقل لعرض عدد  التأكيدات.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>التاريخ والوقت الذي تم فيه تلقي المعاملة.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>نوع المعاملات</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>المبلغ الذي أزيل أو أضيف الى الرصيد</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>الكل</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>اليوم</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>هدا الاسبوع</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>هدا الشهر</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>الشهر الماضي</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>هدا العام</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>المدى...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>استقبل مع</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>أرسل إلى</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>إليك</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Mined</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>اخرى</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>ادخل عنوان أووصف للبحث</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>الحد الأدنى</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>  انسخ عنوان</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation> انسخ التسمية</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>نسخ الكمية</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>نسخ رقم العملية</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>عدل الوصف</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>عرض تفاصيل المعاملة</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>ملف مفصول بفواصل (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>تأكيد</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>النوع</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>وصف</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>عنوان</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>العنوان</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>فشل التصدير</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>نجح التصدير</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>المدى:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>الى</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>إرسال Coins</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;تصدير</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>تحميل البيانات في علامة التبويب الحالية إلى ملف.</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>نسخ احتياط للمحفظة</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>فشل النسخ الاحتياطي</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>نجاح  النسخ الاحتياطي</translation>
    </message>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>خيارات: </translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>حدد مجلد المعلومات</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>جوهر البيت كوين</translation>
    </message>
    <message>
        <source>The %s developers</source>
        <translation>%s المبرمجون</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>تحذير: مساحة القرص منخفضة</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>فشل في الاستماع على أي منفذ. استخدام الاستماع = 0 إذا كنت تريد هذا.</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>عنوان اونيون غير صحيح : '%s'</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>التحقق من المحفظة ...</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>خيارات المحفظة :</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>معلومات</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>فشل توقيع المعاملة</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>قيمة العملية صغيره جدا</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>المعاملة طويلة جدا</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>تحذير</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>تحميل العنوان</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>عنوان البروكسي غير صحيح : '%s'</translation>
    </message>
    <message>
        <source>Make the wallet broadcast transactions</source>
        <translation>إنتاج معاملات بث المحفظة</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>اموال غير كافية</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>تحميل مؤشر الكتلة</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>تحميل المحفظه</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>لا يمكن تخفيض قيمة المحفظة</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>لايمكن كتابة العنوان الافتراضي</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>إعادة مسح</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>انتهاء التحميل</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>خطأ</translation>
    </message>
</context>
</TS>